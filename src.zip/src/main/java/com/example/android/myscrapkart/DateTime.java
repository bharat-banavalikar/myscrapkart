package com.example.android.myscrapkart;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;

public class DateTime extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, GoogleApiClient.OnConnectionFailedListener {

    static int year,month,day,cur_hr,cur_min,sel_year,sel_month,sel_day,sel_hour,sel_min;
    final static String[] mins={ "0", "15", "30", "45" };
    final static String[] hours = { "9", "10", "11", "12", "14", "15", "16", "17" };
    static NumberPicker numPicker ;
    static NumberPicker numPicker2;
    static final int DIALOG_ID=0;
    TextView date;
    static String name;
    static String email;
    private GoogleApiClient client;
    private GoogleApiClient mGoogleApiClient;

    @TargetApi(Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_time);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        name=getIntent().getExtras().getString("nam");
        email=getIntent().getExtras().getString("ema");

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        final Calendar calendar= Calendar.getInstance();
        year=calendar.get(Calendar.YEAR);
        month=calendar.get(Calendar.MONTH)+1;
        day=calendar.get(Calendar.DAY_OF_MONTH);
        cur_min=calendar.get(Calendar.MINUTE);
        cur_hr=calendar.get(Calendar.HOUR_OF_DAY);
        sel_day=day;
        sel_month=month;
        sel_year=year;

        numPicker= (NumberPicker) findViewById(R.id.numberPicker);
        numPicker2= (NumberPicker) findViewById(R.id.numberPicker2);
        //final String[] mins = { "0", "15", "30", "45" };
        // final String[] hours = { "9", "10", "11", "12", "14", "15", "16", "17" };
        int hl = hours.length;
        int ml = mins.length;
        numPicker.setDisplayedValues(null);
        numPicker2.setDisplayedValues(null);
        numPicker.setMinValue(1);
        numPicker.setMaxValue(hl);
        numPicker.setDisplayedValues(hours);
        numPicker2.setMinValue(1);
        numPicker2.setMaxValue(ml);
        numPicker2.setDisplayedValues(mins);

        date=(TextView) findViewById(R.id.date_tv);
        date.setText(""+day+"-"+month+"-"+year);
        date.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        showDialog(DIALOG_ID);
                    }

                }
        );
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .addApi(AppIndex.API).build();
    }
    @Override
    protected Dialog onCreateDialog(int id) {
        if (id== DIALOG_ID)
            return new DatePickerDialog(this,dpickerListner,year,month,day);
        else
            return null;

    }
    private  DatePickerDialog.OnDateSetListener dpickerListner
            = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int y, int monthOfYear, int dayOfMonth) {
            sel_year=y;
            sel_month=monthOfYear+1;
            sel_day=dayOfMonth;
            date.setText(""+sel_day+"-"+sel_month+"-"+sel_year);
        }
    };

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.

        TextView dis = (TextView) findViewById(R.id.bha);
        dis.setText(name);
        TextView dis1 = (TextView) findViewById(R.id.dname);
        dis1.setText(email);

        getMenuInflater().inflate(R.menu.date_time, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_contact) {

            Intent i = new Intent(this,Contact.class);
            startActivity(i);

        } else if (id == R.id.nav_slideshow) {
            Intent i = new Intent(this,AboutUs.class);
            startActivity(i);
        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {
            Auth.GoogleSignInApi.signOut(mGoogleApiClient);
            Intent i = new Intent(this, Gplus.class);
            startActivity(i);

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onStart() {
        super.onStart();
        mGoogleApiClient.connect();
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "DateTime Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.android.myscrapkart/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "DateTime Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.android.myscrapkart/http/host/path")
        );
        AppIndex.AppIndexApi.end(mGoogleApiClient, viewAction);
        mGoogleApiClient.disconnect();
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }
 public void check(View view)
 {
     sel_hour=Integer.parseInt(hours[numPicker.getValue()-1]);
     sel_min=Integer.parseInt(mins[numPicker2.getValue()-1]);
     if(sel_year<year || (sel_year==year && sel_month<month)
             || (sel_year==year && sel_month==month && sel_day<day)
             || (sel_year==year && sel_month==month && sel_day==day && sel_hour<cur_hr)
             || (sel_year==year && sel_month==month && sel_day==day && sel_hour==cur_hr && sel_min<cur_min))
         Toast.makeText(getApplicationContext(), "I know time flies", Toast.LENGTH_LONG).show();
     else {
         Toast.makeText(getApplicationContext(), "Date and Time set", Toast.LENGTH_LONG).show();
         Intent i = new Intent(DateTime.this, MapsActivity.class);
         i.putExtra("ema",email);
         i.putExtra("nam",name);
         startActivity(i);
     }
 }
    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}
